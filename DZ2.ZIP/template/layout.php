<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Try 1</title>
</head>
<body>
<?=$header?>
<?=$menu?>
<?=$content?>
</body>
</html>