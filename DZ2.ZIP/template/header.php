   <header>
        <div class="logo"><img src="https://placehold.it/50x50" alt="logo"></div>
        <div class="cart-parent">

            <div class="dropCart">
                    <div class="total">
                    </div>
                </div>
        </div>
    </header>