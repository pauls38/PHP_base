<?php

echo "Задание 1<br><br>";

$a = mt_rand(-10, 10);
$b = mt_rand(-10, 10);

echo "если a и b положительные, вывести их разность;<br>
         если a и b отрицательные, вывести их произведение;<br>
         если a и b разных знаков, вывести их сумму<br>";
     
if ($a >= 0 && $b >= 0) {
    $res = $a -$b;
    $out = "разность {$a} - {$b} = {$res}";
} elseif ($a < 0 && $b < 0) {
    $res = $a * $b;
    $out = "произведение {$a} * {$b} = {$res}";
} else {
    $res = $a + $b;
    $out = "сумма {$a} + {$b} = {$res}";
}

echo $out;

echo "<br><br><br>Задание 2<br><br>";

echo "<br>Метод switch";
echo "<br>";

switch ($a) {
    case 0:
        echo "{$a} ";
        $a++;
    case 1:
        echo "{$a} ";
        $a++;
    case 2:
        echo "{$a} ";
        $a++;
    case 3:
        echo "{$a} ";
        $a++;    
    case 4:
        echo "{$a} ";
        $a++;
    case 5:
        echo "{$a} ";
        $a++;        
    case 6:
        echo "{$a} ";
        $a++;
    case 7:
        echo "{$a} ";
        $a++;
    case 8:
        echo "{$a} ";
        $a++;
    case 9:
        echo "{$a} ";
        $a++;
    case 10:
        echo "{$a} ";
        $a++;
    case 11:
        echo "{$a} ";
        $a++;
    case 12:
        echo "{$a} ";
        $a++;    
    case 13:
        echo "{$a} ";
        $a++;
    case 14:
        echo "{$a} ";
        $a++;        
    case 15:
        echo "{$a} ";
        $a++;        
}

echo "<br>Метод рекурсия<br>";
$a = mt_rand(0, 15);

echo_val($a);

function echo_val($a)
{
    echo "$a";
    if ($a == 15) return false;
    echo_val($a + 1);
}

$a = rand(0, 15);
echo "a = {$a}<br>";
a: {
    switch ($a) {
        case $a;
            if ($a <= 15) {
                echo $a;
                $a++;
                goto a;
            }
    }
}

echo "<br><br><br>Задание 3<br><br>";
function sum($a, $b)
{
    return $a + $b;
}
function sub($a, $b)
{
    return $a - $b;
}
function mult($a, $b)
{
    return $a * $b;
}
function div($a, $b)
{
    return ($b != 0) ? $a / $b : "Деление на 0";
}

echo "<br><br><br>Задание 4<br><br>";
$arg1 = mt_rand(-10, 10);
$arg2 = mt_rand(-10, 10);
$operation = mt_rand(0, 3);

switch ($operation) {
    case '0':
        $operation = "+";
        break;
    case '1':
        $operation = "-";
        break;
    case '2':
        $operation = "*";
        break;
    case '3':
        $operation = "/";
        break;                            
}
echo "arg1 = {$arg} <br> arg2 = {$arg2} <br> operation = {$operation} <br>";

function mathOperation($arg1, $arg2, $operation)
{

    switch ($operation) {
        case '+':
            $res = sum($arg1, $arg2);
            break;
        case '-':
            $res = sub($arg1, $arg2);
            break;
        case '*':
            $res = mult($arg1, $arg2);
            break;
        case '/':
            $res = div($arg1, $arg2);
            break;
        default:
            $res = "Неверная операция.";                                               
    }
    return $res;
}
echo "результат = " . mathOperation($arg1, $arg2, $operation);

echo "<br><br><br>Задание 6<br><br>";

$val = mt_rand(-5, 5);
$pow = mt_rand(-10, 10);
//простой вариант
function power2($val, $pow)
{
    if ($pow == 0) return 1;
    return $val * power($val, $pow - 1);
}

echo "<br>";
echo "{$val} в степени {$pow} = " . power2($val, $pow);

// С отрицательными степенями
function power($val, $pow)
{
    if ($pow == 0) return 1;
    elseif ($val == 0) return 0;
    elseif ($pow < 0) {
        $pow = -$pow;
        $res = 1 / ($val * power($val, $pow -1));
    } else 
        $res = $val * power($val, $pow - 1);

    return $res;
    
}

echo "{$val} в степени {$pow} = " . power($val, $pow);

$val = mt_rand(-10, 10);
$pow = mt_rand(0, 10);

echo "<br><br><br>Задание 7<br><br>";

$hour = date('G');
$min = date('i');
$sec = date('s');

echo "$hour " . get_word($hour, "hours") . " $min " . get_word($min, "min") . " sec ";

function get_word($number, $format)
{
    //логика получения варианта окончания
    if ($number > 10 && $number <=20) $message = 1;
    else {
        switch ($number % 10) {
            case 1:
                $message = 2;
                break;
            case 2:
            case 3:
            case 4:
                $message = 3;
                break;
            default:
                $message = 1;
        }
    }
// и само окончание по полученному варианту
if ($format == "hours")
    switch ($message) {
        case '1':
            return "часов";
        case '2':
            return "час";
        case '3':
            return 'часа';
    }
if ($format == "min")
    switch ($message) {
        case '1':
            return "минут";
        case '2':
            return "минута";
        case '3':
            return 'минуты';
    }
if ($format == "sec")
    switch ($message) {
        case '1':
            return "секунд";
        case '2':
            return "секунда";
        case '3':
            return 'секунды';
    }
}